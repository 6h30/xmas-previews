Free sample from the Watercolor Christmas series.

You may use these 9 images in your own projects, personal or commercial. You may not resell or redistribute the files.

The artwork was created with an AI image generator from the seller's own written descriptions, then edited and prepared by the seller.

Full sets: https://practicelab.gumroad.com
